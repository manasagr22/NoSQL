import mongoose from "mongoose";

main().catch(err => console.log(err));

async function main() {
  await mongoose.connect('mongodb://127.0.0.1:27017/twitter');
  console.log("MongoDB connected");

  // use `await mongoose.connect('mongodb://user:password@127.0.0.1:27017/test');` if your database has auth enabled
}

const TwitterSchema = new mongoose.Schema({
  user_name: String,
  user_location: String,
  user_description: String,
  user_created: String,
  user_followers: Number,
  user_friends: Number,
  user_favourites: Number,
  user_verified: Boolean,
  date: String,
  text: String,
  source: String,
});

const covid19_tweet = mongoose.model("covid19", TwitterSchema);

async function getVerifieduser() {
  const res = await covid19_tweet.distinct("user_name", { user_verified: true });
  console.log(res)
}

async function getfamousPeopleTweets() {
  const res = await covid19_tweet.find({ user_followers: {$gte: 1000000}}, {text: 1});
  console.log(res)
}

async function getTweetsfromNewDelhi() {
  const res = await covid19_tweet.find({ user_location: { $regex: "New Delhi", $options: "i" } }, {text: 1});

  console.log(res)
}
export async function getTweetsfromDoctors() {
  const res = await covid19_tweet.find({ user_name: { $regex: /Dr. | Dr\s/} }, {user_name: 1, text: 1});

  return res;
}
async function numberOfiphoneUsers() {
  const res = await covid19_tweet.distinct("user_name", { source: { $regex: "iPhone", $options: "i" }}).count();

  console.log(res)
}
export async function users_joined_after_covid19() {
  const res = await covid19_tweet.aggregate([
    { $match: { user_created: { $gte: "2020-03-01 00:00:00" } } },
    { $group: { _id: "$user_name", user_created: { $addToSet: "$user_created" } } }
  ]);
  
  return res;
}




// getTweetsfromDoctors(); // tweets from Doctors
users_joined_after_covid19(); // users joined after covid19 considering after 2020-03-01 00:00:00